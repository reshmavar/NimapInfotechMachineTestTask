package com.example.NimapMachineTest_CategoryProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NimapMachineTestCategoryProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(NimapMachineTestCategoryProductApplication.class, args);
	}

}
