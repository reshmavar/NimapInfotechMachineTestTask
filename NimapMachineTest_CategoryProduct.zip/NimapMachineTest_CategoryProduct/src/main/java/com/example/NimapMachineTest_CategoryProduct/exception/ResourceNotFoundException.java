package com.example.NimapMachineTest_CategoryProduct.exception;

public class ResourceNotFoundException extends RuntimeException {
	
	
	
	public ResourceNotFoundException(String message) {
		super(message);
	}
}