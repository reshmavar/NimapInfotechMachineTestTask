package com.example.NimapMachineTest_CategoryProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NimapMachineTestCategoryProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
